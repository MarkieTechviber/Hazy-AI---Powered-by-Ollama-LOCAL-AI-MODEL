'use strict';

const fs = require('fs');
const fsp = fs.promises;
const path = require('path');

function register(registry) {
  registry.register({
    name: 'artifact.write',
    description: 'Write an artifact (output file, patch, note, etc) to a scoped per-chat artifacts directory (sanitized chatId, resolved+guard+realpath) with post-write verification. Always returns conventional cache/hazy-engine/artifacts/... rel (fs special-cases for handoff independent of custom workspaceDir).',
    risk: 'low_write',
    toolset: 'safe_default',
    requiresConfirmation: false,
    allowedRoles: ['admin', 'cashier', 'user'],
    schema: {
      type: 'object',
      properties: {
        filename: { type: 'string', minLength: 1, maxLength: 200 },
        content: { type: 'string', minLength: 0, maxLength: 200000 },
        action: { type: 'string', enum: ['write', 'read', 'list'] }
      },
      additionalProperties: false
    },
    execute: async ({ filename, content, action = 'write' }, ctx) => {
      try {
        const rawChat = (ctx && ctx.chatId) || 'default';
        const safeChat = String(rawChat).replace(/[^a-zA-Z0-9_.-]/g, '_').slice(0, 64);
        const artifactsRoot = path.resolve(__dirname, '..', '..', 'cache', 'hazy-engine', 'artifacts');
        const base = path.resolve(artifactsRoot, safeChat);
        const rootBase = artifactsRoot.endsWith(path.sep) ? artifactsRoot : artifactsRoot + path.sep;
        const relUp = path.relative(artifactsRoot, base);
        if (relUp.startsWith('..') || (!base.startsWith(rootBase) && base !== artifactsRoot)) {
          return { ok: false, error: { code: 'INVALID_CHATID', message: 'Chat ID escapes artifacts root (traversal blocked).' } };
        }
        await fsp.mkdir(base, { recursive: true });
        // dir-aware support for sub-paths (e.g. assets/foo.js, src/bar.ts from buildData filenames).
        // Sanitize each path segment to prevent traversal/bad chars, mkdir intermediates, preserve logical structure.
        // list is recursive to surface subdirs. Manifest + buildData remain source of truth for original names/reopen (sanitized FS names may differ slightly on special chars).
        function toSafePathSegments(rawName) {
          if (!rawName) return ['artifact.txt'];
          return String(rawName).split(/[\\/]/).filter(Boolean).map(seg => String(seg).replace(/[^a-zA-Z0-9_.-]/g, '_').slice(0, 200));
        }
        if (action === 'list' || (!filename && !content)) {
          const files = [];
          async function walk(dir, prefix = '') {
            try {
              const entries = await fsp.readdir(dir, { withFileTypes: true });
              for (const e of entries) {
                const rel = prefix ? `${prefix}/${e.name}` : e.name;
                if (e.isDirectory()) {
                  await walk(path.join(dir, e.name), rel);
                } else {
                  files.push(rel);
                }
              }
            } catch (_) {}
          }
          await walk(base);
          return { ok: true, data: { chat: safeChat, files, count: files.length, note: 'List from chat-scoped artifacts dir (recursive for subdirs).' } };
        }
        if (action === 'read' || (filename && !content)) {
          const segs = toSafePathSegments(filename);
          const targetDir = segs.length > 1 ? path.join(base, ...segs.slice(0, -1)) : base;
          const target = path.join(targetDir, segs[segs.length - 1]);
          try {
            const data = await fsp.readFile(target, 'utf8');
            return { ok: true, data: { filename: filename, content: data, note: 'Read from artifacts (subdir-aware).' } };
          } catch (re) {
            return { ok: false, error: { code: 'ARTIFACT_NOT_FOUND', message: String(re) } };
          }
        }
        // default write (subdir-aware)
        const segs = toSafePathSegments(filename || 'artifact.txt');
        const targetDir = segs.length > 1 ? path.join(base, ...segs.slice(0, -1)) : base;
        await fsp.mkdir(targetDir, { recursive: true });
        const written = path.join(targetDir, segs[segs.length - 1]);
        await fsp.writeFile(written, String(content || ''), 'utf8');
        let verified = false;
        let size = 0;
        let realWritten = written;
        try {
          realWritten = await fsp.realpath(written);
          const st = await fsp.stat(realWritten);
          verified = realWritten.startsWith(artifactsRoot);
          size = st.size;
        } catch (v) { /* verifier non-fatal */ }
        // rel uses original logical name (from caller) for consistency with manifest/buildData; FS uses sanitized segments
        const relName = String(filename || 'artifact.txt');
        const relPath = `cache/hazy-engine/artifacts/${safeChat}/${relName}`;
        return {
          ok: true,
          data: {
            path: relPath,
            verified,
            size,
            note: 'Artifact written and verified on disk (chat-scoped write, subdir-aware). Use fs.read_file with the conventional relative path (cache/hazy-engine/artifacts/...) or rag.search to retrieve. Reads via fs are workspace-global for project knowledge.'
          }
        };
      } catch (e) {
        return { ok: false, error: { code: 'ARTIFACT_OP_FAILED', message: String(e) } };
      }
    }
  });
}

module.exports = { register };
